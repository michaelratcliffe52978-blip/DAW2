<?php

class triangulo extends Poligono {

    //Método
    public function calcularArea(): void {

    }
}
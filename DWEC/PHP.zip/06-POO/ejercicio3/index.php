<?php

class Poligono {

    public function __construct(
        public string $color,
        public float $altura,
        public float $anchura
    )
    {
        // El cuerpo del constructor queda vacío, a menos que necesites validaciones
    }

    //GETTER AND SETTERS
    function getColor(){
        return $this->color;
    }
    function setColor($color){
        $this->color;
    }
    
    function getAltura(){
        return $this->altura;
    }
    function setAltura($altura){
        $this->altura;
    }

    function getAnchura(){
        return $this->anchura;
    }
    function setAnchura($anchura){
        $this->anchura;
    }

    
}
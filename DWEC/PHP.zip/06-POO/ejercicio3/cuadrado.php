<?php

class cuadrado extends Poligono {
    

}
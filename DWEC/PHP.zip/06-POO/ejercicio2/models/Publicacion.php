<?php

namespace ejercicio2\models;


//Crea una clase «Publicacion» con las siguientes propiedades: «autores», «año», «editorial», «título» y «texto». 
class Publicacion {

    // Definición, declaración y asignación en una sola firma
    public function __construct(
        public string $autores,
        public int $año,
        public string $editorial,
        public string $título,
        public string $texto
    ){
        // El cuerpo del constructor queda vacío, a menos que
        // necesites validaciones)
    }

    //METODOS:
    //Leer: devuelve el contenido de la propiedad texto.
    public function leer(): string {
        return  $this->texto;
    }

    //Escribir: recibe un String y lo concatena a la propiedad texto.
    public function escribir(string $concatenacion): void {
        $this->texto .= $concatenacion;
    }
}

    //A continuación instancia dos objetos distintos y llama a sus métodos.
    $publicacion1 = new Publicacion(
        "Juan Pérez",
        2025,
        "Editorial X",
        "Mi libro",
        "Este es el texto inicial."
    );

    $publicacion2 = new Publicacion(
        "Sushi Lopez",
        2020,
        "Editorial Y",
        "La vida es una",
        "Bla Bla Bla."
    );

    echo $publicacion1->leer();
    $publicacion1->escribir(" Texto añadido.");
    echo $publicacion1->leer();

    echo $publicacion2->leer();
    $publicacion2->escribir(" Texto añadido.");
    echo $publicacion2->leer();
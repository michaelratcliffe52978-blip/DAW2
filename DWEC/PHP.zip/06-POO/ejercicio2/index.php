<?php

include 'ejercicio2/models/Publicacion.php';

$publicacion1 = new ejercicio2\models\Publicacion;


include 'ejercicio2/models/Publicacion.php';

use ejercicio2/models/Publicacion.php;

$publicacion2 = new Publicacion;
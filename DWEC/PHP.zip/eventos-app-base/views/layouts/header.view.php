<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Eventos</h2>

<form method="POST" action="?index.php">

    <input type="text" name="usuario" value="" placeholder="Usuario">
    <input type="password" name="contraseña" value="" placeholder="Contraseña">

    <input type="submit" value="Iniciar Sesión">

</form>
<hr>




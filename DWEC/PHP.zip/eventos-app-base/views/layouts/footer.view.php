<hr>

<form method="GET" action="index.php">

    <select id="idioma" name="idioma">
        <option value="" disabled selected>--Selecciona--</option>
        <option value="eu">Euskera</option>
        <option value="es">Castellano</option>
    </select>

    <input type="submit" value="Enviar">

</form>

</body>
</html>

<?php require "layouts/header.view.php"; ?>

<h3>NUEVO EVENTO</h3>
    

<form method="GET" action="index.php?accion=evento_insertar">

    <label for="titulo">Titulo:</label><br>
    <input type="text" name="titulo"><br><br>

    <label for="categoria">Categoria:</label><br>
    <input type="text" name="categoria"><br><br>

    <label for="descripcion">Descripcion:</label><br>
    <input type="textarea" name="descripcion"><br><br>

    <label for="fecha">Fecha:</label><br>
    <input type="date" name="fecha"><br><br>

    <label for="plazas_totales">Numero de plazas:</label><br>
    <input type="number" name="plazas_totales"><br><br>

    <input type="submit" value="Añadir Evento">

</form>

<br>
<a href="index.php?accion=listarEventos">Volver</a>


<?php require "layouts/footer.view.php"; ?>


<?php require "layouts/header.view.php"; ?>

<h2>Detalle de eventos</h2>

<p><strong>Titulo:</strong> <?= $evento->titulo ?></p>

<p><strong>Categoria:</strong> <?= $evento->categoria ?></p>

<p><strong>Descripcion:</strong> <?= $evento->descripcion ?></p>

<p><strong>Fecha:</strong> <?= $evento->fecha ?></p>

<p><strong>Numero de plazas:</strong> <?= $evento->plazas_totales ?></p>

<p><strong>Estado:</strong> <?= $evento->estado ?></p>


<br>

<a href="index.php?accion=listarEventos">Volver</a>

<?php require "layouts/footer.view.php"; ?>


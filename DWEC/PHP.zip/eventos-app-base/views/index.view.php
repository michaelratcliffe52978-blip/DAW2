<?php require "layouts/header.view.php"; ?>

    <h3>Listado de eventos</h3>
    
    <!-- BOTÓN AÑADIR-->
    <a href="index.php?accion=evento_insertar">
        <button type="button">NUEVO EVENTO</button>
    </a>

    <br>
    <br>

    <table border="2">
         <tr>
            <th>Titulo</th>
            <th>Categoría</th>
            <th>Estado</th>
            <th>Opciones</th>
        </tr>
        <?php foreach($eventos as $evento): ?>
            <tr>
                <td><?= $evento -> titulo ?></td>
                <td><?= $evento -> categoria ?></td>
                <td><?= $evento -> estado ?></td>

                <td>
                    <a href="index.php?accion=evento_detalle&id=<?= $evento->id ?>">
                        <button type="button">Ver más</button>
                    </a>
                    <a href="index.php?accion=evento_estado&id=<?= $evento->estado ?>">
                        <button type="button">Cerrar evento</button>
                    </a>
                    <a href="index.php?accion=evento_borrar&id=<?= $evento->id ?>">
                        <button type="button">Borrar</button>
                    </a>
                    
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <br>

<?php require "layouts/footer.view.php"; ?>


<?php 
require "db_functions.php";

session_start();

$arrayUsuario = array([
    "admin" => "1234"
]);
$usuarios = array(
    "admin" => "1234",
    "laura09" => "0000",
    "samuel07" => "abcd"
);

//SESIONES
if(isset($_POST["usuario"]) && isset($_POST["contraseña"])){
    $usuario = $_POST["usuario"];
    $contraseña = $_POST["contraseña"];

    if(isset($usuarios[$usuario]) && $usuarios[$usuario] == $contraseña){
        $_SESSION["usuario"] = $usuario;
       
        //echos de prueba
        echo "LOG IN CORRECTO";

        //nos vamos al index

    }else{
        echo "USUARIO O CONTRASEÑA INCORRECTO";
    }

}

//COOKIES
if(isset($_GET["idioma"])){
    $idioma = $_GET["idioma"];
    setcookie("idioma", $idioma, time() + 86400 * 30);
   
    $eventos = listarEventos();

    require "views/index.view.php";
    die();

}

function realizarAccion($accion): void{

    switch($accion){
        case "evento_detalle":
            $id = $_GET["id"];

            $evento = obtenerEventoPorId($id);

            require "views/detalle.view.php";
            die();

        case "listarEventos":
            $eventos = listarEventos();
            require "views/index.view.php";
            die();
        
        case "evento_insertar":
            $evento = array(
                "titulo" => $_GET["titulo"],
                "categoria" => $_GET["categoria"],
                "descripcion" => $_GET["descripcion"],
                "fecha" => $_GET["fecha"],
                "plazas_totales" => $_GET["plazas_totales"]
            );

            insertarEvento($evento);
            header("Location: index.php?accion=listarEventos");
            die();

        case "evento_borrar":
            $id = $_GET["id"];

            borrarEvento($id);
            header("Location: index.php?accion=listarEventos");
            die();
        
        case "evento_estado":
            $estado = $_POST["estado"];
            
            actualizarEvento($estado);

            header("Location: index.php?accion=listarEventos");
            die();
        

    }
}



if(isset($_GET["accion"])) {
    realizarAccion($_GET["accion"]);
}

$eventos = listarEventos();

require "views/index.view.php";
?>
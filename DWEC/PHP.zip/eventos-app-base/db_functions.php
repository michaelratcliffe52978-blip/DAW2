<?php 
require_once 'database.php';


function listarEventos(): array{
    $db = getDbConnection();

    $stmt = $db->prepare("SELECT * FROM eventos ORDER BY titulo");
    $stmt->execute();

    return $stmt->fetchAll();

}

function obtenerEventoPorId(int $id): object|false {
    $db = getDbConnection();

    $stmt = $db->prepare("SELECT * FROM eventos WHERE id = :id");

    $datos = array(
        "id" => $id
    );

    $stmt->execute($datos);

    return $stmt->fetch();
}

function insertarEvento(array $evento): void{
    $db = getDbConnection();

    $stmt = $db->prepare("
        INSERT INTO eventos (titulo, categoria, descripcion, fecha, plazas_totales)
        VALUES (:titulo, :categoria, :descripcion, :fecha, :plazas_totales)
    ");
    $stmt->execute($evento);
}

function borrarEvento(int $id): void
{
    $db = getDbConnection();

    $stmt = $db->prepare("DELETE FROM eventos WHERE id = :id");

    $datos = array(
        "id" => $id
    );

    $stmt->execute($datos);
}

function actualizarEvento(array $evento): void
{
    $db = getDbConnection();

    $stmt = $db->prepare("
        UPDATE eventos
        SET estado = :estado
    ");

    $stmt->execute($estado);
}


?>
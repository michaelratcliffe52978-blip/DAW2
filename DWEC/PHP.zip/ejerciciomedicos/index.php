<?php 
require_once "db_functions.php";

//sesion
sesion_start();

$usuarios = array(
    "mike07" => "1234",
    "laura09" => "2345",
    "samuel07" => "abcd"
);

if(isset($_GET["usuario"]) && isset($_GET["contraseña"])){
                        //variable , array
    if(array_key_exists($usuario, $usuarios)){
        $_SESSION["usuario"] = $usuario;



    }else{
        echo "usuario INCORRECTO";
    }

}

$action=$_GET["action"] ?? null;

$id=$_GET["id"] ?? null;

switch ($action){

    case "insertar":

    case "borrar":

}


$medicos = getAll($db);

?>
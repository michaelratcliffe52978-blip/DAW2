<?php
require_once "database.php";

function listarVideojuegos(): array{
    $db = getDbConnection();

    $stmt = $db->prepare("SELECT * FROM videojuegos ORDER BY nombre");
    $stmt->execute();

    return $stmt->fetchAll();

}
//se lo pasamos para que lo guarde como un array
function insertarVideojuego(array $videojuego): void{
    $db = getDbConnection();

    $stmt = $db->prepare("
        INSERT INTO videojuegos (id, nombre, genero, precio)
        VALUES (:id, :nombre, :genero, :precio)
    ");
    $stmt->execute($videojuego);
}

//función para buscar un videojuego por ID
function obtenerVideojuegoPorId(int $id): object|false
{
    $db = getDbConnection();

    $stmt = $db->prepare("SELECT * FROM videojuegos WHERE id = :id");

    $datos = array(
        "id" => $id
    );

    $stmt->execute($datos);

    return $stmt->fetch();
}

//actualizar videojuego para la pestaña editar
function actualizarVideojuego(array $videojuego): void
{
    $db = getDbConnection();

    $stmt = $db->prepare("
        UPDATE videojuegos
        SET nombre = :nombre,
            genero = :genero,
            precio = :precio
        WHERE id = :id
    ");

    $stmt->execute($videojuego);
}

//BORRAR
function borrarVideojuego(int $id): void
{
    $db = getDbConnection();

    $stmt = $db->prepare("DELETE FROM videojuegos WHERE id = :id");

    $datos = array(
        "id" => $id
    );

    $stmt->execute($datos);
}
<?php require "layout/header.view.php"; ?>

<h2>INICIO DE SESIÓN</h2>

<form method="POST" action="index.php">

    <label for="usuario">Usuario</label><br>
    <input type="text" name="usuario"><br>

    <label for="contraseña">Contraseña:</label><br>
    <input type="password" name="contraseña">

    <input type="submit" value="ENVIAR">

</form>


<?php require "layout/footer.view.php"; ?>
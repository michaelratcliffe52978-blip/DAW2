<?php require "layout/header.view.php"?>

<h2>Editar videojuego</h2>

<form method="POST" action="index.php?accion=videojuego_actualizar">

    <input type="hidden" name="id" value="<?= $videojuego->id ?>">

    <label>Nombre:</label><br>
    <input type="text" name="nombre" value="<?= $videojuego->nombre ?>"><br><br>

    <label>Género:</label><br>
    <input type="text" name="genero" value="<?= $videojuego->genero ?>"><br><br>

    <label>Precio:</label><br>
    <input type="number" step="0.01" name="precio" value="<?= $videojuego->precio ?>"><br><br>

    <input type="submit" value="Guardar cambios">

</form>

<?php require "layout/footer.view.php"; ?>
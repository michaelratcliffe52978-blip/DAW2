<?php require "layout/header.view.php"; ?>

<h2>Detalle del videojuego</h2>

<p><strong>ID:</strong> <?= $videojuego->id ?></p>

<p><strong>Nombre:</strong> <?= $videojuego->nombre ?></p>

<p><strong>Género:</strong> <?= $videojuego->genero ?></p>

<p><strong>Precio:</strong> <?= $videojuego->precio ?> €</p>

<br>

<a href="index.php?accion=listarVideojuegos">Volver</a>

<?php require "layout/footer.view.php"; ?>
<?php require "layout/header.view.php"; ?>

<main>

    <h2>Videojuegos</h2>

    <form method="GET" action="index.php">
        <label name="idioma">IDIOMA:</label>

        <select id="idioma" name="idioma">
            <option value="" disabled selected>--Selecciona--</option>
            <option value="eu">Euskera</option>
            <option value="es">Castellano</option>
        </select>

        <input type="submit" value="enviar">
    </form>


    <br>
      <!-- BOTÓN AÑADIR (cuando le das se va a otra página)-->
    <a href="index.php?accion=videojuego_nuevo">
        <button type="button">Añadir videojuego</button>
    </a>

    <br><br>

    <table>
         <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Género</th>
            <th>Precio</th>
            <th>Acciones</th>
        </tr>
        <?php foreach($videojuegos as $videojuego): ?>
            <tr>
                <td><?= $videojuego -> id ?></td>
                <td><?= $videojuego -> nombre ?></td>
                <td><?= $videojuego -> genero ?></td>
                <td><?= $videojuego -> precio ?></td>

                <td>
                    <a href="index.php?accion=videojuego_detalle&id=<?= $videojuego->id ?>">
                        <button type="button">Detalle</button>
                    </a>
                    <a href="index.php?accion=videojuego_editar&id=<?= $videojuego->id ?>">
                        <button type="button">Editar</button>
                    </a>
                    <a href="index.php?accion=videojuego_borrar&id=<?= $videojuego->id ?>">
                        <button type="button">Borrar</button>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

</main>

<?php require "layout/footer.view.php"; ?>
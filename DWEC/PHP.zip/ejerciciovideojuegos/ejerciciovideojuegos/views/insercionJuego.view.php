<?php require "layout/header.view.php"; ?>

<h2>Añadir videojuego</h2>

<form method="POST" action="index.php?accion=videojuego_insertar">

    <label>ID:</label><br>
    <input type="number" name="id"><br><br>

    <label>Nombre:</label><br>
    <input type="text" name="nombre"><br><br>

    <label>Género:</label><br>
    <input type="text" name="genero"><br><br>

    <label>Precio:</label><br>
    <input type="number" step="0.01" name="precio"><br><br>

    <input type="submit" value="Añadir">

</form>
<BR>
<a href="index.php?accion=listarVideojuegos">Volver</a>

<?php require "layout/footer.view.php"; ?>
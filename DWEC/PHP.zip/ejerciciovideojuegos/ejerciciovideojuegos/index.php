<?php
require_once "db_functions.php";
//SESIONES
session_start();

//ARRAY USUARIOS
$usuarios = array(
    "mike07" => "1234",
    "laura09" => "2345",
    "samuel07" => "abcd"
);

/*
//permite que PHP recuerde que ese usuario ya se ha identificado.
if (isset($_SESSION["usuario"])) {
    require "views/index.view.php";
    die();
}
*/

//COOKIE
if(isset($_GET["idioma"])){
    $idioma = $_GET["idioma"];
    setcookie("idioma", $idioma, time() + 86400 * 30);
   
    $videojuegos = listarVideojuegos();

    require "views/index.view.php";
    die();

}

//INICIAR SESIÓN
if(isset($_POST["usuario"]) && isset($_POST["contraseña"])){
    $usuario = $_POST["usuario"];
    $contraseña = $_POST["contraseña"];

    if(isset($usuarios[$usuario]) && $usuarios[$usuario] == $contraseña){
        $_SESSION["usuario"] = $usuario;
       
        //echos de prueba
        //echo "LOG IN CORRECTO";
       
        //nos vamos al index
        //require "views/index.view.php";

        header("Location: index.php?accion=listarVideojuegos");
        die();

    }else{
        echo "USUARIO O CONTRASEÑA INCORRECTO, INTENTELO DE NUEVO";
    }

}

//
function realizarAccion($accion): void{
    switch($accion) {
        case "listarVideojuegos":
            $videojuegos = listarVideojuegos();
            require "views/index.view.php";
            die();

        //CAMBIAR DE PESTAÑA
         case "videojuego_nuevo":
            require "views/insercionJuego.view.php";
            die();
       
        //MOSTRAR FORMULARIO DE EDITAR
        case "videojuego_editar":
            $id = $_GET["id"];
            $videojuego = obtenerVideojuegoPorId($id);
            require "views/editarJuego.view.php";
            die();

        //EDITAR
        case "videojuego_actualizar":
            $videojuego = array(
                "id" => $_POST["id"],
                "nombre" => $_POST["nombre"],
                "genero" => $_POST["genero"],
                "precio" => $_POST["precio"]
            );

            actualizarVideojuego($videojuego);

            header("Location: index.php?accion=listarVideojuegos");

            die();
           
        // INSERTAR
        case "videojuego_insertar":

            $videojuego = array(
                "id" => $_POST["id"],
                "nombre" => $_POST["nombre"],
                "genero" => $_POST["genero"],
                "precio" => $_POST["precio"]
            );

            insertarVideojuego($videojuego);

            header("Location: index.php?accion=listarVideojuegos");

            die();
       
        //BORRAR
        case "videojuego_borrar":
            $id = $_GET["id"];

            borrarVideojuego($id);

            header("Location: index.php?accion=listarVideojuegos");

            die();
       
        //DETALLE
        case "videojuego_detalle":
            $id = $_GET["id"];
            $videojuego = obtenerVideojuegoPorId($id);

            require "views/detalleJuego.view.php";
            die();
    }
}

//Si me llega una acción por la URL, llama a la función realizarAccion() con esa acción
if(isset($_GET["accion"])) {
    realizarAccion($_GET["accion"]);
}

require "views/login.view.php";
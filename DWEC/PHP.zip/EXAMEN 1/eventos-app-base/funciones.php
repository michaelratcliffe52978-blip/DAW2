<?php
require 'database.php';

function getAll(){
    $db = getDbConnection();
    $stmt = $db->prepare('SELECT * FROM eventos;');
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getById($id){
    $db = getDbConnection();
    $data = ['id' => $id];
    $stmt = $db->prepare('SELECT * FROM eventos WHERE id = :id;');
    $stmt->execute($data);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function insertar($evento){
    $db = getDbConnection();
    $stmt = $db->prepare('INSERT INTO eventos (titulo,categoria,descripcion,fecha,plazas_totales) VALUES (:titulo,:categoria,:descripcion,:fecha,:plazas_totales);');
    $stmt->execute($evento);
}

function eliminar($id){
    $db = getDbConnection();
    $data = ['id' => $id];
    $stmt = $db->prepare('DELETE FROM eventos WHERE id = :id;');
    $stmt->execute($data);
}

function actualizar($id){
    $db = getDbConnection();
    $data = ['id' => $id];
    $stmt = $db->prepare('UPDATE eventos SET estado = "cerrado" WHERE id = :id;');
    $stmt->execute($data);
}

function getPersonsById($id){
    $db = getDbConnection();
    $data = ['id' => $id];
    $stmt = $db->prepare('SELECT * FROM asistentes WHERE evento_id = :id;');
    $stmt->execute($data);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

?>
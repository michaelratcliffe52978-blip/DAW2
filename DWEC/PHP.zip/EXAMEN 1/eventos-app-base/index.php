<?php

$_SESSION['usuarios'] = [
    'nombre' => 'administrador', 
    'usuario' => 'admin',
    'password' => '1234'
];

require 'funciones.php';

if (isset($_GET['accion'])) {
    $accion = $_GET['accion'];
    switch ($accion) {
        case 'detalles':
            $evento = getById($_GET['id']);
            $listaPersonas = getPersonsById($_GET['id']);
            require 'vistas/detalles.view.php';
            die();
        case 'cookie':
            setcookie('Idioma',$_GET['idioma']);
            break;
        case 'mostarInsertar':
            require 'vistas/insertar.view.php';
            die();
        case 'insertar':
            $eventoNuevo = ['titulo' => $_GET['titulo'],
                            'categoria' => $_GET['categoria'],
                            'descripcion' => $_GET['decripcion'],
                            'fecha' => $_GET['fecha'],
                            'plazas_totales' => $_GET['plazas']
                            ];
            insertar($eventoNuevo);
            break;
        case 'eliminar':
            eliminar($_GET['id']);
            break;
        case 'actualizar':
            if ($_GET['estado'] == "abierto") {
                actualizar($_GET['id']);
            }
            break;
        default:
        break;            
    }
}

$resultado = getAll();
require 'vistas/index.view.php';

?>
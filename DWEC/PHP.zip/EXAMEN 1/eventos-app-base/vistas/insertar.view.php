<?php
    require 'layout/head.php';
?>

<form action="index.php" method="get">

    <label for="">Titulo</label>
    <input type="text" name="titulo"><br>

    <label for="">Categoria</label>
    <input type="text" name="categoria"><br>

    <label for="">Descripcion</label>
    <textarea name="decripcion"></textarea><br>

    <label for="">Fecha</label>
    <input type="date" name="fecha"><br>

    <label for="">Nuemro de plazas</label>
    <input type="number" name="plazas"><br>


    <input type="submit" value="Crear">
    <input type="hidden" name="accion" value="insertar">

</form>

<a href="index.php">Volver</a>
<?php
require 'layout/footer.php';

?>
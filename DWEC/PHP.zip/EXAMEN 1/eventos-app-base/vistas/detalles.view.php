<?php
    require 'layout/head.php';
?>

    <table border="1">
        <tr>
            <th>Titulo</th>
            <td><?=$evento['titulo'] ?></td>
        </tr>
        <tr>
            <th>Categoria</th>
            <td><?=$evento['categoria']?></td>
        </tr>
        <tr>
            <th>Descripcion</th>
            <td><?=$evento['descripcion']?></td>
        </tr>
        <tr>
            <th>Fecha</th>
            <td><?=$evento['fecha']?></td>
        </tr>
        <tr>
            <th>Plazas totales</th>
            <td><?=$evento['plazas_totales']?></td>
        </tr>
        <tr>
            <th>Estado</th>
            <td><?=$evento['estado']?></td>
        </tr>
    </table> <br>

    <h3>Listado de asistentes</h3>

    <ul>
        <?php
        if (count($listaPersonas) > 0):
        ?>
            <?php
            foreach ($listaPersonas as $persona):
            ?>
            <li><?=$persona['nombre']?></li>
            <?php
                endforeach;
            ?>
        <?php
        else:
        ?>
        <p>Todavia no hay asistentes en este evento</p>
        <?php
            endif;
        ?>
    </ul>

    <br>
    <a href="index.php">Volver</a>
    <br>


<?php
require 'layout/footer.php';
?>
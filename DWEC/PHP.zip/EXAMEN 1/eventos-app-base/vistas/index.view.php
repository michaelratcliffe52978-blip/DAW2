<?php
    require 'layout/head.php';
?>


<a href="index.php?accion=mostarInsertar">Crear evento</a>

<h3>Listado de eventos</h3>

<table border=1>
    <tr>
        <th>Titulo</th>
        <th>Categoria</th>
        <th>Estado</th>
        <th>Opciones</th>
    </tr>
    <?php
        foreach ($resultado as $evento):
    ?>
    <tr>
        <td><?= $evento['titulo']?></td>
        <td><?= $evento['categoria']?></td>
        <td><?= $evento['estado']?></td>
        <td><a href="index.php?accion=detalles&id=<?=$evento['id']?>">Ver mas</a>
            <a href="index.php?accion=eliminar&id=<?=$evento['id']?>">Eliminar</a>
            <a href="index.php?accion=actualizar&id=<?=$evento['id']?>&estado=<?=$evento['estado']?>">Cambiar a cerrado</a></td>
    </tr>
    <?php
        endforeach;
    ?>
</table>


<?php
require 'layout/footer.php';
?>
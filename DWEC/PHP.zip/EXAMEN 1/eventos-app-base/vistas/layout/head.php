<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
    if ($_COOKIE['Idioma'] == "castellano"):
?>
<h1>Eventos</h1>
<?php
    endif;  
?>
<?php
    if ($_COOKIE['Idioma'] == "euskera"):
?>
<h1>Ekitaldiak</h1>
<?php
    endif;
?>

<br>

<form action="index.php" method="get">

    <label>Usuario: </label>
    <input type="text" name="usuario"><br>

    <label>Contraseña: </label>
    <input type="text" name="password"><br>

    <input type="hidden" name="accion" value="login">
    <input type="submit" value="Entrar">

</form>


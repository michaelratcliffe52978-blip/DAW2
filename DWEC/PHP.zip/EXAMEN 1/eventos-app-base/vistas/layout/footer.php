

<form action="" method="get">
    <select name="idioma" >
        <option value="euskera">Euskera</option>
        <option value="castellano">Castellano</option>
    </select>
    <input type="hidden" name="accion" value="cookie">
    <input type="submit" value="Enviar">
</form>
    

</body>
</html>
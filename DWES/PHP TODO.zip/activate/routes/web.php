<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ActivityController;
use App\Http\Controllers\CategoryController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/about', function () {
    return view('about', [
        "nombre" => "ACTIVATE APP!"
    ]);
});

Route::get('/about/{nombre}', function (string $nombre) {
    return view('about', [
        "nombre" => $nombre
    ]);
});

Route::get('/prueba', function () {
    return "Ésta es una prueba para saber si la ruta funciona correctamente :) 🧡";
});

Route::get('/hola', function () {
    return "hola";
});

Route::get('/activities', [ActivityController::class, 'index'])
    ->name('activities.index');

Route::get('/activities/{id}', [ActivityController::class, 'show'])
    ->whereNumber('id')
    ->name('activities.show');

Route::get('/bienvenido', [ActivityController::class, 'bienvenido'])
    ->name('activities.bienvenido');

Route::get('/category/{slug}', [CategoryController::class, 'show'])
    ->name('activities.category');

Route::permanentRedirect('/activity', '/activities');
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle actividad</title>
</head>
<body>

    <h1>¡BIENVENIDO!</h1>

    <a href="{{ route('activities.index') }}">VOLVER</a>

    
</body>
</html>
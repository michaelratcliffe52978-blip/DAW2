<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle actividad</title>
</head>
<body>

    <h1>{{ $activity['title'] }}</h1>

    <p>ID: {{ $activity['id'] }}</p> 
    <p>Categoría: {{ $activity['category'] }}</p>
    <p>Ubicación: {{ $activity['location'] }}</p>
    <p>Fecha: {{ $activity['starts_at'] }}</p>
    <p>Capacidad: {{ $activity['capacity'] }}</p>

    <hr>

    @if ($anterior >= 1)
        <a href="/activities/{{ $anterior }}">Anterior</a>
    @endif
    
    @if ($siguiente <= $total)
        <a href="/activities/{{ $siguiente }}">Siguiente</a>
    @endif

    <br><br>

    <a href="/activities">Volver al listado</a>

</body>
</html>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Categorías</title>
</head>
<body>

    <h1>CATEGORÍA: {{ $category }}</h1>

    <ul>
        @foreach ($categories as $activity)
            <li>
                {{ $activity['title'] }}
            </li>
        @endforeach
    </ul>

    <a href="/activities">Volver al listado</a>

</body>
</html>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About</title>
</head>
<body>
    <x-layout title="Próximas actividades">

        <h1>Próximas actividades</h1>

        <a href="{{ route('activities.bienvenido') }}">¡BIENVENIDO!</a>

        @foreach ($activities as $activity)
            <ul>
                <li>
                    {{ $activity['id'] }},
                    <a href="{{ route('activities.show', $activity['id']) }}">
                    {{ $activity['title'] }}
                    </a>
                    {{ $activity['category'] }},
                    {{ $activity['location'] }},
                    {{ $activity['starts_at'] }},
                    {{ $activity['capacity'] }}
                </li>
            </ul>
        @endforeach

        <p>▶  <a href="{{ route('activities.category', 'taller') }}">CATEGORÍAS</a></p>


    </x-layout>
    
</body>
</html>

<nav>
    <ul>
        <li><strong>Actívate</strong></li>
    </ul>

    <ul>
        <li><a href="{{ route('activities.bienvenido') }}">Bienvenido</a></li>
        <li><a href="{{ route('activities.index') }}">Inicio</a></li>
        <li><a href="{{ route('activities.category', 'taller') }}">Categorias</a></li>
    </ul>
</nav>
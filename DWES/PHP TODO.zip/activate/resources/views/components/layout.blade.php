<!-- layout.blade.php sirve para crear una plantilla común que utilizan todas las páginas de tu aplicación-->
@props(['title'])

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>{{ $title }}</title>

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css"
    >
    <link rel="stylesheet" href="app.css">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}"><!-- asset sirve para generar la ruta correcta a un archivo que está dentro de la carpeta public -->
</head>

<body>


    <main class="container">
        @include('partials.nav')
        {{ $slot }}


        <footer class="footer">
            FOOTER
        </footer>

    </main>

    

</body>
</html>
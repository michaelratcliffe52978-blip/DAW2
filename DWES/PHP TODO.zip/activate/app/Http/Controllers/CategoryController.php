<?php 

namespace App\Http\Controllers;

use Illuminate\View\View;

class CategoryController extends Controller
{
    public function show(string $slug): View
    {
        $activityController = new ActivityController();

        $activities = array_filter(
            $activityController->activities(),
            fn (array $activity) => $activity['category'] === $slug
        );

        abort_if(empty($activities), 404);

        return view('activities.category', [
            'categories' => $activities,
            'category' => $slug
        ]);
    }
}
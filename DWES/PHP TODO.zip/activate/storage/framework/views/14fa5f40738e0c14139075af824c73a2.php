<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle actividad</title>
</head>
<body>

    <h1><?php echo e($activity['title']); ?></h1>

    <p>ID: <?php echo e($activity['id']); ?></p> 
    <p>Categoría: <?php echo e($activity['category']); ?></p>
    <p>Ubicación: <?php echo e($activity['location']); ?></p>
    <p>Fecha: <?php echo e($activity['starts_at']); ?></p>
    <p>Capacidad: <?php echo e($activity['capacity']); ?></p>

    <hr>

    <?php if($anterior >= 1): ?>
        <a href="/activities/<?php echo e($anterior); ?>">Anterior</a>
    <?php endif; ?>
    
    <?php if($siguiente <= $total): ?>
        <a href="/activities/<?php echo e($siguiente); ?>">Siguiente</a>
    <?php endif; ?>

    <br><br>

    <a href="/activities">Volver al listado</a>

</body>
</html><?php /**PATH C:\laragon\www\activate\resources\views/activities/show.blade.php ENDPATH**/ ?>
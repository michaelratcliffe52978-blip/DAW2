<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Categorías</title>
</head>
<body>

    <h1>CATEGORÍA: <?php echo e($category); ?></h1>

    <ul>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($activity['title']); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <a href="/activities">Volver al listado</a>

</body>
</html><?php /**PATH C:\laragon\www\activate\resources\views/activities/category.blade.php ENDPATH**/ ?>
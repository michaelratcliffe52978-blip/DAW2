<nav>
    <ul>
        <li><strong>Actívate</strong></li>
    </ul>

    <ul>
        <li><a href="<?php echo e(route('activities.bienvenido')); ?>">Bienvenido</a></li>
        <li><a href="<?php echo e(route('activities.index')); ?>">Inicio</a></li>
        <li><a href="<?php echo e(route('activities.category', 'taller')); ?>">Categorias</a></li>
    </ul>
</nav><?php /**PATH C:\laragon\www\activate\resources\views/partials/nav.blade.php ENDPATH**/ ?>
document.addEventListener("DOMContentLoaded", function () {

    const formulario = document.querySelector("form");

    formulario.addEventListener("submit", function (event) {

        try {
            const usuario = document.getElementById("usuario").value.trim();
            const contrasena = document.getElementById("contrasena").value;

            if (usuario === "") {
                throw new Error("El usuario no puede estar vacío.");
            }

            if (contrasena === "") {
                throw new Error("La contraseña no puede estar vacía.");
            }

            if (usuario.length < 3) {
                throw new Error("El usuario debe tener al menos 3 carácteres.");
            }

            if (contrasena.length < 8) {
                throw new Error("La contraseña debe tener al menos 8 carácteres.");
            }

        } catch (error) {
            event.preventDefault();
            alert(error.message);
        }

    });
});

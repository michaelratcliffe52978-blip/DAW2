
<?php

require __DIR__ . '/vendor/autoload.php';

use SebastianBergmann\Timer\Timer;

// Crear el temporizador
$timer = new Timer();

// Iniciar el tiempo
$timer->start();

// Mostrar 100.000 números aleatorios
for ($i = 0; $i < 100000; $i++) {
    echo rand(1, 100) . "<br>";
}

// Detener el temporizador
$duration = $timer->stop();

// Mostrar el tiempo empleado
echo "<h3>Tiempo empleado: " . $duration->asString() . "</h3>";

?>

<?php

require 'vendor/autoload.php';

use Egibide\Admin;
use Egibide\RegularUser;

//Creamos el generador de datos falsos
$faker = Faker\Factory::create();

//CREAR 5 REGULARUSERS
for ($i = 0; $i < 5; $i++) {
    $regularuser = new RegularUser(
        //Faker genera nombres, apellidos, emails y usuarios aleatorios.
        $faker->userName(),
        $faker->firstName(),
        $faker->lastName(),
        $faker->email(),
        $faker->password(),
        $faker->userName(),
        $faker->userName()
    );

    $regularuser->login();
    $regularuser->showActions();
    $regularuser->editarPerfil();
    $regularuser->logout();
}

//CREAR 5 ADMINS
for ($i = 0; $i < 5; $i++) {
    $admin = new Admin(
        $faker->userName(),
        $faker->firstName(),
        $faker->lastName(),
        $faker->email(),
        $faker->password(),
        //Genera un nivel de administrador entre 1 y 3.
        rand(1, 3)
    );

    $admin->login();
    $admin->showActions();
    $admin->desactivarUsuario();
    $admin->logout();
}

?>
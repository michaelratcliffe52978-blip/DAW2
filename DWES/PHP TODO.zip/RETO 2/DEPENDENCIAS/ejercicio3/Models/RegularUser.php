<?php

namespace Egibide;

class RegularUser extends User {
    protected $twitter;
    protected $instagram;

    public function __construct($username, $nombre, $apellidos, $email, $password, $twitter, $instagram) {

        parent::__construct($username, $nombre, $apellidos, $email, $password);

        $this->twitter = $twitter;
        $this->instagram = $instagram;
    }

    //MÉTODOS
    public function showActions() {
        $this->log->info("Ejecutando el método RegularUser::showActions por el usuario " . $this->username);
    }

    public function editarPerfil() {
        $this->log->info("Ejecutando el método RegularUser::editarPerfil por el usuario " . $this->username);
    }
}
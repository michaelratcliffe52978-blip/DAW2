<?php

namespace Egibide;

class Admin extends User {

    protected $admin_level;

    public function __construct($username, $nombre, $apellidos, $email, $password, $admin_level) {

        parent::__construct($username, $nombre, $apellidos, $email, $password);

        $this->admin_level = $admin_level;
    }

    //MÉTODOS
    public function showActions() {
        $this->log->info("Ejecutando el método Admin::showActions por el usuario " . $this->username);
    }

    public function desactivarUsuario() {
        $this->log->info("Ejecutando el método Admin::desactivarUsuario por el usuario " . $this->username);
    }
}
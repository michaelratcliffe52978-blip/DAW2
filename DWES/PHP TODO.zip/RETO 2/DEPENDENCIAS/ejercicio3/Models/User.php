<?php

namespace Egibide;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

abstract class User {
    protected $username;
    protected $nombre;
    protected $apellidos;
    protected $email;
    protected $password;
    protected \DateTime $ultimo_acceso;
    protected Logger $log;

    public function __construct($username, $nombre, $apellidos, $email, $password) {

        $this->username = $username;
        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->email = $email;
        $this->password = $password;
        $this->ultimo_acceso = new \DateTime();

        $this->log = new Logger('usuarios');
        $this->log->pushHandler(
            new StreamHandler(__DIR__ . '/../app.log', Logger::INFO)
        );

        $this->log->info("Ejecutando el método User::__construct por el usuario " . $this->username);
    }

    //MÉTODOS:
    //showActions (abstracto)
    abstract public function showActions();

    //LOGIN
    public function login() {
        $this->ultimo_acceso = new \DateTime();
        $this->log->info("Ejecutando el método User::login por el usuario " . $this->username);
    }

    //LOGOUT
    public function logout() {
        $this->log->info("Ejecutando el método User::logout por el usuario " . $this->username);
    }

    //GETTERS AND SETTERS
    public function getUsername() {
        return $this->username;
    }
    public function setUsername($username) {
        $this->username = $username;
    }

    public function getNombre() {
        return $this->nombre;
    }
    public function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    public function getApellidos() {
        return $this->apellidos;
    }
    public function setApellidos($apellidos) {
        $this->apellidos = $apellidos;
    }

    public function getEmail() {
        return $this->email;
    }
    public function setEmail($email) {
        $this->email = $email;
    }

    public function getPassword() {
        return $this->password;
    }
    public function setPassword($password) {
        $this->password = $password;
    }

    public function getUltimoAcceso() {
        return $this->ultimo_acceso;
    }
    public function setUltimoAcceso($ultimo_acceso) {
        $this->ultimo_acceso = $ultimo_acceso;
    }

    public function getLog() {
        return $this->log;
    }
}

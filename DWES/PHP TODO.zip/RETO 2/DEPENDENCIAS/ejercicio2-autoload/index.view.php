
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="GET">
        <button type="submit" name="accion" value="enfermar">
            Enfermar
        </button>

        <button type="submit" name="accion" value="curar">
            Curar
        </button>
    </form>
</body>
</html>

<?php

require 'vendor/autoload.php';

use Egibide\Paciente;

if (isset($_GET['accion'])) {

    $paciente = new Paciente("Michael", "Garcia", 22);

    if ($_GET['accion'] == 'enfermar') {
        $paciente->enfermar();
    }

    if ($_GET['accion'] == 'curar') {
        $paciente->curar();
    }
}

require 'index.view.php';
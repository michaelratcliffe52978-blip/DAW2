<?php

namespace Egibide;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class Paciente {

    private $nombre;
    private $apellidos;
    private $edad;
    private $logger;

    public function __construct($nombre, $apellidos, $edad) {

        $this->nombre = $nombre;
        $this->apellidos = $apellidos;
        $this->edad = $edad;

        $this->logger = new Logger('paciente');

        $this->logger->pushHandler(
            new StreamHandler(__DIR__ . '/../app.log', Logger::INFO)
        );
    }

    public function enfermar() {
        $this->logger->info('He enfermado');
    }

    public function curar() {
        $this->logger->info('Me he curado');
    }
}

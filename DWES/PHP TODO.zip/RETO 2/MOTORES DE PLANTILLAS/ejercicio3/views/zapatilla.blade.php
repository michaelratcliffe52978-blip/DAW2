<table border="1">
    <tr>
        <td>Marca</td>
        <td>Modelo</td>
        <td>Tipo</td>
        <td>Precio</td>
    </tr>
    <tr>
        @foreach($zapatillas as $zapatilla)

        <td>{{ $zapatilla -> marca }}</td>
        <td>{{ $zapatilla -> modelo }}</td>
        <td>{{ $zapatilla -> tipo }}</td>
        <td>{{ $zapatilla -> precio }}</td>
    
        @endforeach
    </tr>
</table>
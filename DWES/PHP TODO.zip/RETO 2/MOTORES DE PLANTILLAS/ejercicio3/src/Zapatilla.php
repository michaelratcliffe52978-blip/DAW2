<?php

class Zapatilla{
    public $marca;
    public $modelo;
    public $tipo;
    public $precio;

    public function __construct($marca, $modelo, $tipo, $precio) {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->tipo = $tipo;
        $this->precio = $precio;        
    }
}

?>
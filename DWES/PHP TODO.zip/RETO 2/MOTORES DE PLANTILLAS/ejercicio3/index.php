<?php

require 'vendor/autoload.php';
require 'src/Zapatilla.php';

use eftec\bladeone\BladeOne;

$blade = new BladeOne();

$zapatilla = [
    new Zapatilla("Adidas", "Modelo 1", "Baloncesto", 140),
    new Zapatilla("Nike", "Modelo 2", "Running", 100),
    new Zapatilla("Puma", "Modelo 3", "Casual", 80)
]


?>
<?php

require 'vendor/autoload.php';

use eftec\bladeone\BladeOne;

$blade = new BladeOne();

echo $blade->run("bienvenido", [
    "nombre" => "Michael",
    "nombre2" => "Amaia"
]);



?>
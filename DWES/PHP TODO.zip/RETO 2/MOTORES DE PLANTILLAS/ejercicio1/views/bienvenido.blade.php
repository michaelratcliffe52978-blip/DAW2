<h1>¡Bienvenido {{ $nombre }}!</h1>
<h1>¡Bienvenido {{ $nombre2 }}!</h1>
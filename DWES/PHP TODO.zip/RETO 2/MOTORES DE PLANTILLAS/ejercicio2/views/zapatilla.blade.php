<table border="1">
    <tr>
        <td>Marca</td>
        <td>{{ $zapatilla->marca }}</td>
    </tr>
    <tr>
        <td>Modelo</td>
        <td>{{ $zapatilla->modelo }}</td>
    </tr>
    <tr>
        <td>Tipo</td>
        <td>{{ $zapatilla->tipo }}</td>
    </tr>
    <tr>
        <td>Precio</td>
        <td>{{ $zapatilla->precio }} €</td>
    </tr>
</table>
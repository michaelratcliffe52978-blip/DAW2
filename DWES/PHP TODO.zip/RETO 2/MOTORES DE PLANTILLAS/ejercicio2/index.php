<?php

//esto nos carga todas las clases que necesitemos
require 'vendor/autoload.php';

use ejercicio2\src\Zapatilla.php;
use eftec\bladeone\BladeOne;

$blade = new BladeOne();

$zapatilla = new Zapatilla(
    "Adidas",
    "MARQUEE BOOST",
    "Zapatilla de baloncesto",
    140
);

//blade->run significa ejecuta la plantilla que se llama zapatilla 
echo $blade->run("zapatilla", [
    "zapatilla" => $zapatilla
]);

?>
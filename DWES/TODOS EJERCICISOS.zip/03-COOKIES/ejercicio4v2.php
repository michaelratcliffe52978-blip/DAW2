<?php 
    session_start();


    if(isset($_POST["añadir"])) {
        $_SESSION["usuario"];
        
        echo 
    }

    
    if(isset($_GET["nombre"])){
        session_start();
        session_unset();        // Eliminar todos los valores de la sesión (se pueden seguir almacenando valores)

    }
    
    require "ejercicio4v2.view.php";
?>